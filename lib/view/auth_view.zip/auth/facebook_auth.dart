import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:newhorizontrav/controller/auth/facebook_auth_controller.dart';
import 'package:newhorizontrav/utils/app_consts.dart';

class FacebookAuth extends StatelessWidget {
  const FacebookAuth({super.key});

  @override
  Widget build(BuildContext context) {
    final size = AppConsts.sizeContext(context);
    final cs = Theme.of(context).colorScheme;
    return GetBuilder<FacebookSigninController>(
      init: FacebookSigninController(), // إن كنت تسجّل الكنترولر بمكان آخر، احذف init
      builder: (c) {
        final u = c.user;
        return Center(
          child: c.loading
              ? const CircularProgressIndicator()
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (u == null) ...[
                      SizedBox(
                        width: size.width * 0.9,
                        child: TextButton.icon(
                          style: TextButton.styleFrom(
                            foregroundColor: (Get.isDarkMode)? Colors.white: Colors.black,
                            side: BorderSide(color: cs.tertiary, width: 1),
                          ),
                          onPressed: c.signIn,
                          icon: SvgPicture.asset(AppConsts.facebookLogo, width: 24, height: 24),
                          label: Text('Sign in with Facebook'.tr),
                        ),
                      ),
                    ] else ...[
                      CircleAvatar(
                        radius: 28,
                        backgroundImage: u.photoURL != null ? NetworkImage(u.photoURL!) : null,
                        child: u.photoURL == null ? const Icon(Icons.person) : null,
                      ),
                      const SizedBox(height: 12),
                      Text(u.displayName ?? 'User'),
                      Text(u.email ?? 'email'),
                      Text(u.phoneNumber ?? 'phoneNumber'),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: c.signOut, child: Text('Sign out'.tr)),
                    ],
                    if (c.error != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        c.error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ],
                ),
        );
      },
    );
  }
}
