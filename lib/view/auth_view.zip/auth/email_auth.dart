import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:newhorizontrav/controller/auth/email_auth_controller.dart';
import 'package:newhorizontrav/utils/app_consts.dart';

class EmailAuth extends StatefulWidget {
  const EmailAuth({super.key});

  @override
  State<EmailAuth> createState() => _EmailAuthState();
}

class _EmailAuthState extends State<EmailAuth> {

  @override
  Widget build(BuildContext context) {
    final size = AppConsts.sizeContext(context);
    return GetBuilder<EmailAuthController>(
      init: EmailAuthController(),
      builder: (c) {
        final u = c.user;
        return Container(
          width: size.width * 0.9,
          padding: const EdgeInsets.all(0),
          child: c.loading
              ? const Center(child: CircularProgressIndicator())
              : u == null
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (!c.loginMode) ...[
                      TextField(
                        controller: c.name,
                        decoration: InputDecoration(
                          labelText: 'Name'.tr,
                          prefixIcon: const Icon(FontAwesomeIcons.user),
                        ),
                        onSubmitted: (val) {
                          print("name: $val");
                        },
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: c.email,
                      decoration: InputDecoration(
                        labelText: 'Email'.tr,
                        prefixIcon: const Icon(Icons.email_outlined),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: c.password,
                      decoration: InputDecoration(
                        labelText: 'Password'.tr,
                        prefixIcon: const Icon(Icons.lock_outlined),
                        suffixIcon: IconButton(
                          onPressed: () {
                            c.toggleObscureText();
                          }, 
                          icon: Icon(c.obscureText ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                        ), 
                      ),
                      obscureText: c.obscureText,
                    ),
                    InkWell(
                      onTap: () {
                        c.resetPassword(c.email.text);
                      },
                      child: Container(
                        padding: const EdgeInsetsDirectional.only(top: 4, bottom: 4, start: 8),
                        child: Text(
                          "Forgot your password?".tr, 
                          style: TextStyle(color: AppConsts.secondaryColor, fontSize: AppConsts.sm)
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () => c.loginMode ? c.signIn(c.email.text, c.password.text) : c.signUp(c.name.text, c.email.text, c.password.text),
                      child: Text(c.loginMode ? 'Sign in'.tr : 'Sign up'.tr),
                    ),
                    // TextButton(onPressed: () => c.resetPassword(_email.text), child: const Text('نسيت كلمة المرور؟')),
                    const SizedBox(height: 12),
                    TextButton(
                      style: ElevatedButton.styleFrom(
                        side: BorderSide(color: AppConsts.secondaryColor, width: 1),
                      ),
                      onPressed: () {
                        c.loginMode = !c.loginMode;
                        c.update();
                      },
                      child: Text(c.loginMode ? 'Create an new account'.tr : 'I have an account, sign in'.tr),
                    ),
                    if (c.error != null) ...[const SizedBox(height: 8), Text(c.error!, style: const TextStyle(color: Colors.red))],
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(u.email ?? ''),
                    Text(u.displayName ?? 'User'),
                    const SizedBox(height: 12),
                    ElevatedButton(onPressed: c.signOut, child: Text('Sign out'.tr)),
                  ],
                ),
        );
      },
    );
  }
}
