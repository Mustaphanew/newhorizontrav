import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:newhorizontrav/controller/auth/google_auth_controller.dart';
import 'package:newhorizontrav/utils/app_consts.dart';

class GoogleAuth extends StatelessWidget {
  const GoogleAuth({super.key});

  @override
  Widget build(BuildContext context) {
    final size = AppConsts.sizeContext(context);
    return GetBuilder<GoogleAuthController>(
      builder: (c) {
        final u = c.user;
        return Center(
          child: c.loading
              ? const CircularProgressIndicator()
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (u == null) ...[
                      SizedBox(
                        width: size.width * 0.9,
                        child: ElevatedButton.icon(
                          onPressed: c.signIn, 
                          label: Text('Sign in with Google'.tr),
                          icon: SvgPicture.asset(AppConsts.googleLogo, width: 24, height: 24),
                        ),
                      ),
                    ] else ...[
                      CircleAvatar(
                        radius: 28,
                        backgroundImage: u.photoURL != null ? NetworkImage(u.photoURL!) : null,
                        child: u.photoURL == null ? const Icon(Icons.person) : null,
                      ),
                      const SizedBox(height: 12),
                      Text(u.displayName ?? 'User'),
                      Text(u.email ?? 'email'),
                      Text(u.phoneNumber ?? 'phone'),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: c.signOut, child: Text('Sign out'.tr)),
                    ],
                    if (c.error != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        c.error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ],
                ),
        );
      },
    );
  }
}
